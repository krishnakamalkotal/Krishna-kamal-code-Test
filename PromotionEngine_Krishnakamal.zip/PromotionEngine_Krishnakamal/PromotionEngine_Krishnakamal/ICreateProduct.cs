﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionEngine_Krishnakamal
{
    interface ICreateProduct
    {
        public List<Product> GetProductList(int a);
    }
}
